package com.google.android.apps.plus.realtimechat;

import com.google.android.apps.plus.service.ServiceResult;

public class RealTimeChatServiceListener
{
  void onC2dmRegistration(ServiceResult paramServiceResult, String paramString)
  {
  }

  public void onConnected()
  {
  }

  public void onConversationCreated$2ae26fbd(int paramInt, CreateConversationOperation.ConversationResult paramConversationResult, RealTimeChatServiceResult paramRealTimeChatServiceResult)
  {
  }

  public void onConversationsLoaded$abe99c5()
  {
  }

  public void onDisconnected$13462e()
  {
  }

  public void onResponseReceived$1587694a(int paramInt, RealTimeChatServiceResult paramRealTimeChatServiceResult)
  {
  }

  public void onResponseTimeout(int paramInt)
  {
  }

  public void onUserPresenceChanged(long paramLong, String paramString, boolean paramBoolean)
  {
  }

  public void onUserTypingStatusChanged(long paramLong, String paramString1, String paramString2, boolean paramBoolean)
  {
  }
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.google.android.apps.plus.realtimechat.RealTimeChatServiceListener
 * JD-Core Version:    0.6.2
 */