package com.google.android.apps.plus.fragments;

import android.widget.ProgressBar;

public abstract interface Refreshable
{
  public abstract void setProgressBar(ProgressBar paramProgressBar);
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.google.android.apps.plus.fragments.Refreshable
 * JD-Core Version:    0.6.2
 */