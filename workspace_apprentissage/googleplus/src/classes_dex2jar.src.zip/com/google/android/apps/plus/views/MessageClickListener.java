package com.google.android.apps.plus.views;

public abstract interface MessageClickListener
{
  public abstract void onCancelButtonClicked(long paramLong);

  public abstract void onMediaImageClick(String paramString1, String paramString2);

  public abstract void onRetryButtonClicked(long paramLong);

  public abstract void onUserImageClicked(String paramString);
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.google.android.apps.plus.views.MessageClickListener
 * JD-Core Version:    0.6.2
 */