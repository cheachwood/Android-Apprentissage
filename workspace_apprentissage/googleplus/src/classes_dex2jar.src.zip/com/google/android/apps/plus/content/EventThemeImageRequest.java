package com.google.android.apps.plus.content;

public final class EventThemeImageRequest extends MediaImageRequest
{
  public EventThemeImageRequest(String paramString)
  {
    super(paramString, 3, 0);
  }

  public final String getDownloadUrl()
  {
    return getUrl();
  }
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.google.android.apps.plus.content.EventThemeImageRequest
 * JD-Core Version:    0.6.2
 */