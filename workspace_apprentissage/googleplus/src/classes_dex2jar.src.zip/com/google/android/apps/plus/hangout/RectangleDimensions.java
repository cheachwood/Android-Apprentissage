package com.google.android.apps.plus.hangout;

final class RectangleDimensions
{
  public final int height;
  public final int width;

  public RectangleDimensions(int paramInt1, int paramInt2)
  {
    this.width = paramInt1;
    this.height = paramInt2;
  }
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.google.android.apps.plus.hangout.RectangleDimensions
 * JD-Core Version:    0.6.2
 */