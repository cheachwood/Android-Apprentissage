package com.google.android.apps.plus.fragments;

public abstract interface SettableItemAdapter
{
  public abstract void setItemHeight(int paramInt1, int paramInt2);
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.google.android.apps.plus.fragments.SettableItemAdapter
 * JD-Core Version:    0.6.2
 */