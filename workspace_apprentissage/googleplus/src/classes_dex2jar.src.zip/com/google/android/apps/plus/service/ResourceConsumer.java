package com.google.android.apps.plus.service;

public abstract interface ResourceConsumer
{
  public abstract void bindResources();

  public abstract void onResourceStatusChange$1574fca0(Resource paramResource);

  public abstract void unbindResources();
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.google.android.apps.plus.service.ResourceConsumer
 * JD-Core Version:    0.6.2
 */