package com.android.volley.toolbox;

import com.android.volley.Cache;

public final class NoCache
  implements Cache
{
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.android.volley.toolbox.NoCache
 * JD-Core Version:    0.6.2
 */