package com.android.volley;

public final class AuthFailureError extends VolleyError
{
  public AuthFailureError()
  {
  }

  public AuthFailureError(NetworkResponse paramNetworkResponse)
  {
    super(paramNetworkResponse);
  }

  public final String getMessage()
  {
    return super.getMessage();
  }
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.android.volley.AuthFailureError
 * JD-Core Version:    0.6.2
 */