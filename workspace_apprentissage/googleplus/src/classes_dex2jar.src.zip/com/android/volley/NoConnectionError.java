package com.android.volley;

public final class NoConnectionError extends NetworkError
{
  public NoConnectionError()
  {
  }

  public NoConnectionError(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.android.volley.NoConnectionError
 * JD-Core Version:    0.6.2
 */