package com.android.volley;

public final class TimeoutError extends VolleyError
{
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.android.volley.TimeoutError
 * JD-Core Version:    0.6.2
 */