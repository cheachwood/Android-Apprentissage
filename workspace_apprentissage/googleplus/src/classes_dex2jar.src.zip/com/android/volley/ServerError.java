package com.android.volley;

public final class ServerError extends VolleyError
{
  public ServerError()
  {
  }

  public ServerError(NetworkResponse paramNetworkResponse)
  {
    super(paramNetworkResponse);
  }
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.android.volley.ServerError
 * JD-Core Version:    0.6.2
 */