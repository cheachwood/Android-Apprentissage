package com.android.gallery3d.util;

public abstract interface Future<T>
{
}

/* Location:           C:\Dev\Java\android\adt-bundle-windows\workspace\googleplus\classes_dex2jar.jar
 * Qualified Name:     com.android.gallery3d.util.Future
 * JD-Core Version:    0.6.2
 */